#!/usr/bin/env python
# coding: utf-8

# In[1]:


#2장 10(2)번
import numpy as np
from scipy import sparse
data = np.array([3,2,8,4,5]) #행렬 중 0이 아닌 원소 리스트 생성 
row_pos = np.array([0,0,1,1,2]) #0이 아닌 원소들의 열위치
col_pos = np.array([1,3,0,2,3]) #0이 아닌 원소들의 행위치
sparse_coo = sparse.coo_matrix((data, (row_pos,col_pos))) #sparse패키지의 coo_matrix를 이용하여 형식으로 희소행렬 생성 
print(sparse_coo.toarray())


# In[2]:


#2장 12번
f_total=i=0 #0프레임부터, 총합의 초기값은 0
score=[]
while True: #점수 입력
    first=int(input('첫번째 점수 입력 : '))
    second=int(input('두번째 점수 입력 : '))
    
    if i<=9 and first==10: #0~9프레임에서 스트라이크
        result='STRIKE'
        next_first=int(input('다음 세트 첫번째 점수 입력 : '))
        next_second=int(input('다음 세트 두번째 점수 입력 : '))
        score=first+second+next_first+next_second
        f_total += first+second+next_first+next_second
        
        if i<8 and next_first==10:#더블 스트라이크
            next_next_first=int(input('첫번째 점수 입력 : '))
            next_next_second=int(input('두번째 점수 입력 : '))
            score +=next_next_first+next_next_second
            f_total += next_next_first+next_next_second
            i+=1  
        elif i<8 and (next_first+next_second)==10 : #스트라이크 후 스페어
            result='SPARE'
            next_next_first=int(input('보류! 다다음세트 첫번째 점수 입력 : '))
            score +=next_first+next_second+ next_next_first
            f_total += next_first+next_second+next_next_first   
            i+=1
        elif i<8 and (next_first+next_second)!=10 : #스트라이크 후 일반 
            score=first+second+2*(next_first+next_second)
            f_total += (next_first+next_second)
        else: #스트라이크 후 보너스
            print('결과 : ',result,'현재점수:',score, '총점수 : ',f_total)
            break
           
    elif i<=9 and (first+second)==10 : #스페어
        result='SPARE'
        next_first=int(input('보류! 다음 세트 첫번째 점수 입력 : '))
        next_second=int(input('보류! 다음 세트 두번째 점수 입력 : '))
        
        score= first+second+ next_first
        f_total += first+second+ next_first
        if i!=9 and (next_first+next_second)==10: #스페어 후 스페어
            next_next_first=int(input('보류! 다다음세트 첫번째 점수 입력 : '))
            score +=next_first+next_second+ next_next_first
            f_total += next_first+next_second+next_next_first
            i+=1
        elif i!=9 and next_first==10: #스페어 후 스트라이크
            next_next_first=int(input('첫번째 점수 입력 : '))
            next_next_second=int(input('두번째 점수 입력 : '))
            score += next_next_first+next_next_second
            f_total += next_next_first+next_next_second
            i+=1
           
    elif i<=9 and (first+second)!=10: #스트라이크, 스페어 아무것도 아님 
        score = first+second
        f_total+=first+second
        result= "NONE"
        
    else: # 보너스가 없다면 9프레임 후 종료 
        print('결과 : ',result,'현재점수:',score, '총점수 : ',f_total)
        break
    i+=1
    print('결과 : ',result,'현재점수:',score, '누적점수 : ',f_total)


# In[3]:


#3장 2번
def max(x, y):  #두 원소 중 최댓값을 찾는 max함수 생성
    if x > y :
        return x
    else:
        return y

def max_array(array, len): #원소 개수를 확장해, 재귀함수 생성
    if len == 1:   #원소개수가 1개라면 그 원소가 최댓값임을 이용
        return array[0]
    else:  #원소개수가 1이 아닌경우
        return max(array[len - 1], max_array(array, len - 1))

temp_array = [33, 44, 5, 66, 139, 90, 45, 23] #예

print (max_array(temp_array, len(temp_array))) #결과


# In[4]:


#3장 3번
def is_palind(word): #회문인지 검사하는 함수정의
    if len(word) < 2: #단어의 길이가 2보다 작은경우 회문
        return True
    if word[0] != word[-1]: #단어의길이가 2이상이고 단어의 맨앞,맨뒤글자비교
        return False
    return is_palind(word[1:-1]) #단어 중 글자를 계속 비교


# In[5]:


print(is_palind('strawberrs')) #예시
print(is_palind('level'))


# In[6]:


#3장 6번
def string_permutation(s, i, n): #문자열로 순열을 생성하는 재귀함수 생성
    if i==n: 
        print(''.join(s) )
    else: 
        for j in range(i,n): #문자의 각자리 위치 변경
            s[i], s[j] = s[j], s[i] 
            string_permutation(s, i+1, n) 
            s[i], s[j] = s[j], s[i]
a = input() #문자열을 입력받음
x = len(a) 
s = list(a) 
print(string_permutation(s, 0, x)) 


# In[7]:


def nharmonic(N) : #조화수를 구하는 재귀함수 정의 
    harmonic = 1.00 #첫번째 조화수는 1이므로 정의
 
    for i in range(2, N + 1) : 
        harmonic += 1 / i #조화수 정의
 
    return harmonic #조화수 출력 
     
if __name__ == "__main__" :
    
    N=100 #예시: n이 100이라고 가정 
    print(round(nharmonic(N),5)) #소수점 5째자리까지 출력
   






